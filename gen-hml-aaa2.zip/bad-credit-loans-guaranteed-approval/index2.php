<?php 
		include("../spider.php");
		$isbot = is_bot();
		include("index-bot.php");
		?>